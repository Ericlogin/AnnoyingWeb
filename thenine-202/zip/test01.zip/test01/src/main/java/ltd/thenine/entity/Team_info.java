package ltd.thenine.entity;

public class Team_info {
    public Team team;
    public Team_PoRel team_poRel;
    public Team_PrRel team_prRel;
    public Team_SkRel team_skRel;
}
