package ltd.thenine.entity;

public class User_info {
    public User user;
    public User_PoRel user_poRel;
    public User_PrRel user_prRel;
    public User_RiRel user_riRel;
    public User_RoRel user_roRel;
    public User_SkRel user_skRel;
}
