package ltd.thenine.entity;

public class User_PrRel {
    private String program_ids;
    private int program_id;
    private int user_id;

    public String getProgram_ids() {
        return program_ids;
    }

    public void setProgram_ids(String program_ids) {
        this.program_ids = program_ids;
    }

    public int getProgram_id() {
        return program_id;
    }

    public void setProgram_id(int program_id) {
        this.program_id = program_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
}
