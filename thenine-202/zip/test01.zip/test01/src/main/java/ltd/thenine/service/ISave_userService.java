package ltd.thenine.service;

import ltd.thenine.entity.*;

public interface ISave_userService {
    String save_user_info1(User user);
   // String save_user_info(User user, User_PoRel user_poRel, User_PrRel user_prRel,User_RiRel user_riRel,User_RoRel user_roRel, User_SkRel user_skRel);
}
