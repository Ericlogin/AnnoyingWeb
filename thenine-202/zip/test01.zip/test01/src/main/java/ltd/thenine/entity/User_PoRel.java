package ltd.thenine.entity;

public class User_PoRel {
    private String position_ids;
    private int position_id;
    private int user_id;



    public String getPosition_ids() {
        return position_ids;
    }

    public void setPosition_ids(String position_ids) {
        this.position_ids = position_ids;
    }

    public int getPosition_id() {
        return position_id;
    }

    public void setPosition_id(int position_id) {
        this.position_id = position_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
}
