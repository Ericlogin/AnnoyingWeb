package ltd.thenine.service;

import ltd.thenine.entity.Team_PoRel;

import java.util.List;

public interface ITeam_PoRelService {

    List<Team_PoRel> searchTeam(int position_id);

}
