package ltd.thenine.entity;

public class Skill {

    private int skill_id;
    private String skill_tag;

    public int getSkill_id() {
        return skill_id;
    }

    public void setSkill_id(int skill_id) {
        this.skill_id = skill_id;
    }

    public String getSkill_tag() {
        return skill_tag;
    }

    public void setSkill_tag(String skill_tag) {
        this.skill_tag = skill_tag;
    }
}
