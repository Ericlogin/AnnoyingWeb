package ltd.thenine.service;


import ltd.thenine.entity.User_image;


public interface IUser_imageService {

    User_image selectImg(int image_id);

}
