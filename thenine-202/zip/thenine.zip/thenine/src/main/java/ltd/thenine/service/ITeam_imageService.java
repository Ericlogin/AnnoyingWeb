package ltd.thenine.service;


import ltd.thenine.entity.Team_image;


public interface ITeam_imageService {

    Team_image selectImg(int image_id);

}
