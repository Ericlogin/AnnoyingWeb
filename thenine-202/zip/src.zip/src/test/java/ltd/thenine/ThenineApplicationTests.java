package ltd.thenine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThenineApplicationTests {

    @Test
    void contextLoads() {
    }

}
