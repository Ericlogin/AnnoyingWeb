package ltd.thenine.entity;

public class User_image {
}
